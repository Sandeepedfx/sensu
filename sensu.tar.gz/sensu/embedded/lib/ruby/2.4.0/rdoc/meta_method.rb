# frozen_string_literal: false
##
# MetaMethod represents a meta-programmed method

class RDoc::MetaMethod < RDoc::AnyMethod
end

